<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/template.css" rel="stylesheet" type="text/css" />
  <jdoc:include type="head" />
  <title>Клуб Русич</title>
</head>
<body>
  <div class="site">
    <div class="header">
      <!-- user-1 -->
      <div class="sitename"><jdoc:include type="modules" name="position-1" />Клуб Славянских боевых искусств <span class="name">"РУСИЧ"</span></div>
      <!-- end user-1 -->
      <!-- user-2 -->
      <div class="topmenu"><jdoc:include type="modules" name="position-2" /></div>
      <!-- end user-2-->
    </div>
    <div class="conteiner">
      <table class="table" border="1" height="700">
        <tr>
          <td class="leftfield"></td>
      <!-- user-3 -->
          <td class="content"><jdoc:include type="component" /></td>
      <!-- end user-3 -->
          <td class="rightfield"></td>
        </tr>
      </table></div>
      <!-- user-4 -->
    <div class="bottom"><jdoc:include type="modules" name="position-1" /></div>
      <!-- end user-4 -->
  </div>
</body>
</html>